﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml;

namespace ShowHierarchyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Order of traversing is Child to parent OR Parent to child");
            //string OrderOfTraversing = Console.ReadLine();

            Console.WriteLine("Enter your Input");
            string userInput = Console.ReadLine();

            XElement xelement = XElement.Load("CMEXMLFile.xml");
            IEnumerable<XElement> menus = xelement.Elements();

            XmlDocument doc = new XmlDocument();
            doc.Load("CMEXMLFile.xml");
            XmlNodeList elemList = doc.GetElementsByTagName("Country");

            List<Country> countries = GetListOfCountries(elemList);
            GetChildToParent(countries, userInput);
            Console.ReadLine();
        }

        private static void GetChildToParent(List<Country> countries, string userInput)
        {
            string str = string.Empty;
            bool isValue = false;

            string stringChildToParent = string.Empty;
            string stringParentToChild = string.Empty;
            foreach (Country country in countries)
            {
                if (!isValue)
                {
                    if (country.CountryName == userInput)
                    {
                        stringChildToParent = country.CountryName;
                        stringChildToParent = stringChildToParent + "-->" + "World";
                        isValue = true;
                    }
                    else
                    {
                        foreach (State state in country.DicCountryState.Where(x => x.Key == country.CountryName).FirstOrDefault().Value.ToList())
                        {
                            if (!isValue)
                            {
                                if (state.StateName == userInput)
                                {
                                    stringChildToParent = state.StateName;
                                    stringChildToParent = stringChildToParent + "-->" + country.CountryName;
                                    stringChildToParent = stringChildToParent + "-->" + "World";
                                    isValue = true;
                                }
                                else
                                {
                                    foreach (City city in state.DicStateCity.Where(x => x.Key == state.StateName).FirstOrDefault().Value.ToList())
                                    {
                                        if (!isValue)
                                        {
                                            if (city.CityName == userInput)
                                            {
                                                stringChildToParent = city.CityName;
                                                stringChildToParent = stringChildToParent + "-->" + state.StateName;
                                                stringChildToParent = stringChildToParent + "-->" + country.CountryName;
                                                stringChildToParent = stringChildToParent + "-->" + "World";
                                                isValue = true;
                                            }
                                            else
                                            {
                                                foreach (Place place in city.DicCityPlace.Where(x => x.Key == city.CityName).FirstOrDefault().Value.ToList())
                                                {
                                                    if (!isValue)
                                                    {
                                                        if (place.PlaceName == userInput)
                                                        {
                                                            stringChildToParent = place.PlaceName;
                                                            stringChildToParent = stringChildToParent + "-->" + city.CityName;
                                                            stringChildToParent = stringChildToParent + "-->" + state.StateName;
                                                            stringChildToParent = stringChildToParent + "-->" + country.CountryName;
                                                            stringChildToParent = stringChildToParent + "-->" + "World";
                                                            isValue = true;
                                                        }
                                                        else
                                                        {
                                                            foreach (string famousPlace in place.DicPlaceFamousPlace.Where(x => x.Key == place.PlaceName).FirstOrDefault().Value.ToList())
                                                            {
                                                                if (city.CityName == userInput)
                                                                {
                                                                    Console.WriteLine(famousPlace);
                                                                    stringChildToParent = famousPlace;
                                                                    stringChildToParent = stringChildToParent + "-->" + place.PlaceName;
                                                                    stringChildToParent = stringChildToParent + "-->" + city.CityName;
                                                                    stringChildToParent = stringChildToParent + "-->" + state.StateName;
                                                                    stringChildToParent = stringChildToParent + "-->" + country.CountryName;
                                                                    stringChildToParent = stringChildToParent + "-->" + "World";
                                                                    isValue = true;
                                                                }

                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Console.WriteLine("Child to parent traversing");
            Console.WriteLine(stringChildToParent);
        }

        private static List<Country> GetListOfCountries(XmlNodeList elemList)
        {
            List<Country> countries = new List<Country>();
            for (int i = 0; i < elemList.Count; i++)
            {
                Country country = new Country();
                country.CountryName = elemList[i].Attributes[0].Value;
                List<State> states = new List<State>();
                for (int j = 0; j < elemList[i].ChildNodes.Count; j++)
                {
                    State state = new State();
                    state.StateName = elemList[i].ChildNodes[j].Attributes[0].Value;
                    List<City> cities = new List<City>();
                    for (int k = 0; k < elemList[i].ChildNodes[j].ChildNodes.Count; k++)
                    {
                        City city = new City();
                        city.CityName = elemList[i].ChildNodes[j].ChildNodes[k].Attributes[0].Value;
                        List<Place> places = new List<Place>();
                        for (int l = 0; l < elemList[i].ChildNodes[j].ChildNodes[k].ChildNodes.Count; l++)
                        {
                            List<string> FamousPlaces = new List<string>();
                            Place place = new Place();
                            place.PlaceName = elemList[i].ChildNodes[j].ChildNodes[k].ChildNodes[l].Attributes[0].Value;
                            for (int m = 0; m < elemList[i].ChildNodes[j].ChildNodes[k].ChildNodes[l].ChildNodes.Count; m++)
                            {
                                FamousPlaces.Add(elemList[i].ChildNodes[j].ChildNodes[k].ChildNodes[l].ChildNodes[m].Attributes[0].Value);
                            }

                            place.DicPlaceFamousPlace.Add(place.PlaceName, FamousPlaces);
                            places.Add(place);
                        }
                        city.DicCityPlace.Add(city.CityName, places);
                        cities.Add(city);
                    }
                    state.DicStateCity.Add(state.StateName, cities);
                    states.Add(state);
                }
                country.DicCountryState.Add(country.CountryName, states);
                countries.Add(country);
            }
            return countries;
        }
    }

    class Country
    {
        public string CountryName = string.Empty;
        public Dictionary<string, List<State>> DicCountryState = new Dictionary<string, List<State>>();

    }

    class State
    {
        public string StateName = string.Empty;
        public Dictionary<string, List<City>> DicStateCity = new Dictionary<string, List<City>>();
    }

    class City
    {
        public string CityName = string.Empty;
        public Dictionary<string, List<Place>> DicCityPlace = new Dictionary<string, List<Place>>();
    }

    class Place
    {
        public string PlaceName = string.Empty;
        public Dictionary<string, List<string>> DicPlaceFamousPlace = new Dictionary<string, List<string>>();

    }
}
